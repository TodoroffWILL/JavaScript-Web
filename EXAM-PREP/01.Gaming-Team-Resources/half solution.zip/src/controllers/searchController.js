const router = require('express').Router();
const gameManager = require('../manager/gameManager');

router.route('/search').get(async (req, res) => {
  const games = await gameManager.getAll().lean();

  res.render('search', { games });
});

module.exports = router;
